#include "HelloWorld.h"

void HelloWorld::say_hello()
{
    std::cout << name() << ": Hello World." << std::endl;
}
