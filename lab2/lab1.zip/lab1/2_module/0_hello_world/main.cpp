#include "HelloWorld.h"

int sc_main(int argc, char *argv[]) {
    HelloWorld hello("hello");
    // Print the hello world
    hello.say_hello();
    return (0);
}
